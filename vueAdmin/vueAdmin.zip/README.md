

# url调整
.env.production 中 VUE_APP_BASE_API 调整 及 .env.development 中 VUE_APP_BASE_API 调整

# 问题汇总
运行项目

使用npm  
```
npm install -g mirror-config-china --registry=http://registry.npm.taobao.org  
npm install  
npm uninstall webpack  
npm install webpack@^4.0.0 --save-dev  
npm install webpack -g  
npm install webpack --save-dev  
```

使用yarn
```
yarn install  
yarn dev  
yarn build
```



