import $ from 'jquery'
function kefu() {
  return $('#nb_invite_ok').click();
}


export {
  kefu
}


